import 'package:flutter/material.dart';
import 'package:projek_mealdb/helper/shared_preference.dart';
import 'package:projek_mealdb/transit/change_page_login.dart';
import 'package:projek_mealdb/view/home_page.dart';
import 'package:projek_mealdb/view/konversi_uang.dart';
import 'package:projek_mealdb/view/konversi_waktu.dart';
import 'package:projek_mealdb/view/profiel.dart';



class MyHomePage extends StatefulWidget {
  final String title;
  final String username;
  MyHomePage({Key? key, required this.username, required this.title,}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  final List<Widget> _widgetOptions = <Widget>[
    HomePage(username: '',),
    CalendarPage(),
    conversiMoney(),
    ProfilePage(name: "Febrianti Windy", nim: "123200036", photoUrl: ""),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Welcome " + widget.username + "! This is Desert Recipes For You"),
          actions: [
            IconButton(
           onPressed: () {
             SharedPreference().setLogout();
             Navigator.pushAndRemoveUntil(
               context,
               MaterialPageRoute(
                   builder: (context) => const ChangePageLogin()),
                   (_) => false,
             );
           },
           icon: const Icon(Icons.logout),
         )
        ],
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            backgroundColor: Colors.grey,
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.access_alarm_outlined),
            backgroundColor: Colors.grey,
            label: 'Time',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.money),
            backgroundColor: Colors.grey,
            label: 'konversi',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box_rounded),
            backgroundColor: Colors.grey,
            label: 'konversi',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.brown,
        onTap: _onItemTapped,
      ),
    );
  }
}

class MenuScreen extends StatelessWidget {
  @override
  Widget build(BuildContext index) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[


        ],
      ),
    );
  }
}



