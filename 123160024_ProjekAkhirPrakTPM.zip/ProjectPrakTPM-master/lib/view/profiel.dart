import 'package:flutter/material.dart';
import 'package:projek_mealdb/LoginRegisterPage/login_page.dart';
import 'package:projek_mealdb/view/detail_profile.dart';
import 'package:projek_mealdb/view/pesankesan.dart';


class ProfilePage extends StatelessWidget {
  final String name;
  final String nim;
  final String photoUrl;

  const ProfilePage({
    Key? key,
    required this.name,
    required this.nim,
    required this.photoUrl,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      // appBar: AppBar(
      //   title: Text('Profile'),
      // ),
      body: Column(
        children: [
          SizedBox(height: 24),
          Center(
            child: CircleAvatar(
              radius: 50,
              backgroundImage: NetworkImage("https://media.licdn.com/dms/image/D5603AQE8PZ-stX3tog/profile-displayphoto-shrink_800_800/0/1678772445249?e=1690416000&v=beta&t=5etDflQFCyFn1AEYg0rf2UK-u5bWL7-cYM0i8uTbTsM"),
            ),
          ),
          SizedBox(height: 16),
          Center(
            child: Text(
              name,
              style: TextStyle(fontSize: 24),
            ),
          ),
          Center(
            child: Text(
              nim,
              style: TextStyle(fontSize: 20),
            ),
          ),
          SizedBox(height: 30.0),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailPage(name: name, nim: nim, photoUrl: "https://media.licdn.com/dms/image/D5603AQE8PZ-stX3tog/profile-displayphoto-shrink_800_800/0/1678772445249?e=1690416000&v=beta&t=5etDflQFCyFn1AEYg0rf2UK-u5bWL7-cYM0i8uTbTsM",
                      birthPlace: "Kendari", birthDate: "22 Februari 2002", classYear: "IF-A", futureGoal: "Lulus dan Sukses"),
                ),
              );
            },
            child: Text('Info Detail'),
          ),

          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (index) => HelpPage()),
              );
            },
            child: Text('Pesan & Kesan'),
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all<Size>(Size(100, 35)),
              backgroundColor:
              MaterialStateProperty.all<Color>(Colors.brown),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),

          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (index) => LoginPage()),
              );
            },
            child: Text('Logout'),
            style: ButtonStyle(
              minimumSize: MaterialStateProperty.all<Size>(Size(100, 35)),
              backgroundColor:
              MaterialStateProperty.all<Color>(Colors.brown),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
          ),

        ],
      ),
    );
  }
}
