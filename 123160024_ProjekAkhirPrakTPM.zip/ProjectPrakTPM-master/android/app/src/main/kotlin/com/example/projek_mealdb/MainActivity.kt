package com.example.projek_mealdb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
